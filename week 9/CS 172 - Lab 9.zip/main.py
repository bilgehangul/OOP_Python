import random
from BST import *


def populateList(n,s):
	##TODO: implement your logic here
	return None 

def searchLength(lst, n):
    pass
        
def listToBST(lst):
    pass

if __name__ == "__main__":
    ##TODO: implement your logic here
	pass
	
		
		