from fraction import *

def H(n):
	return pass
	
def T(n):
	return pass
	
def Z(n):
	return pass
	
def R(n,b):
	return pass
	

if __name__ == "__main__":
	#TODO
	return pass