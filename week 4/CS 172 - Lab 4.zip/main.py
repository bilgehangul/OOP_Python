#Mark Boady and Matthew Burlick
#Drexel University 2020
#CS 172


import random
import time
## TODO: import CustomMonster class here 

def driver():
	## TODO: Get first monster's name, health, description, basicAttackDamange, specialAttackDamage, defenseDamage, defenseName here.
	# Instantiate a CustomMonster using that info.
	first = None  #this should be an instance of your CustomMonster class

    # TODO: Get second monster's name, health, description, basicAttackDamange, specialAttackDamage, defenseDamage, defenseName here.
	# Instantiate a CustomMonster using that info.
	second = None  #this should be an instance of your CustomMonster class
		
    winner = monster_battle(first,second)


#This function has two monsters fight and returns the winner
def monster_battle(m1, m2):

	#first reset everyone's health!
	#####TODO######

	#next print out who is battling
	print("Starting Battle Between")
	print(m1.getName()+": "+m1.getDescription())
	print(m2.getName()+": "+m2.getDescription())
	
	
	#Whose turn is it?
	attacker = None
	defender = None
	
	#Select Randomly whether m1 or m2 is the initial attacker
	#to other is the initial definder
	######TODO######
	
	
	print(attacker.getName()+" goes first.")
	#Loop until either monster is unconscious (health < 1) or choose to stop.
	while( m1.getHealth() > 0 and m2.getHealth() > 0):
        #Ask the user a move among special attack, basic attack, defense or the stop.
        move = input('Pick one of these (s)pecial attack, (b)asic attack, (d)efense or sto(p):')		

		#It will be nice for output to record the damage done
		before_health=defender.getHealth()
		
		#for each of the options above, apply the appropriate attack and 
		#print out who did what attack on whom
		#basic attack
		if( move.lower() == None):
			# Attacker uses basic attack on defender 
			# and print results by calling print_results function
			######TODO######
			pass
		#defense attack
		elif move.lower() == None
			# Defend! and print results by calling print_results function
			######TODO######
			pass
		#special attack
		elif move.lower() == None:
			# Special Attack! and print results by calling print_results function
			######TODO######
			pass
		elif move.lower() == 'p':
		    #stop the fight
		    pass
		
		#Swap attacker and defender
		######TODO######
		
		#Print the names and healths after this round
		######TODO######
		
	# Print out who won.
    # Return who won
	######TODO######


#Print status updates
####TODO####
def print_results(attacker,defender,attack,hchange):
	####TODO####
	# Get the name of the attacker and the defender.
	# then give status updates based on the the attack. For more
	# info refer to the example trace.
	res=""
	print(res)

#----------------------------------------------------
if __name__=="__main__":
	#Ideally ever battle will be different
	#But for reproducability, we'll seed the random number generator as 0
	
	random.seed(0)
	driver()