#Simple Maze Class
#Mark Boady
#Drexel University
#CS 172

class Room:
	#Constructor sets the description
	#And all four doors should be initially set to None
	def __init__(self,descr):
		# TODO
		pass
		
	#Accessors
	#Return the correct values
	def __str__(self):
		# TODO: 
		pass
	def getNorth(self):
		# TODO: 
		pass
	def getSouth(self):
		# TODO: 
		pass
	def getEast(self):
		# TODO: 
		pass
	def getWest(self):
		# TODO: 
		pass
		
	#Mutators
	#Update the values
	def setDescription(self,d):
		# TODO: 
		pass
	def setNorth(self,n):
		# TODO: 
		pass
	def setSouth(self,s):
		# TODO: 
		pass
	def setEast(self,e):
		# TODO: 
		pass
	def setWest(self,w):
		# TODO: 
		pass
	