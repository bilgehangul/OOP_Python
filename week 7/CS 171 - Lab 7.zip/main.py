def play(my_maze):
	#Play a game
	while not my_maze.atExit():
		## TODO: Get direction from user
    
		## TODO: Based on choice do what was asked.

		break  #remove this once you've implemented your code.    	
	print("You found the exit!")


# **SIMPLE_MAZE** :  This maze should be solved when the movements east and north  are applied in that order. This means you arrive at the exit when you go east room and then the north room. The description of each room doesn't matter since the correctness will be graded. The ORDER matters. 
## TODO: Create the SIMPLE_MAZE
SIMPLE_MAZE = None


# **INTERMEDIATE_MAZE** :  This maze should be solved when the movements are west, west, west, north, east. This means you arrive at the exit when you go west room, then west room again, then west room again, then take north and then finally the final east room. At the end of the movements, atExit should be true when it is called. The description of each room doesn't matter since the correctness will be graded. 
## TODO: Create the INTERMEDIATE_MAZE
INTERMEDIATE_MAZE = None


if __name__=="__main__":
	
	## TODO: Define this play function above and run on your INTERMEDIATE_MAZE
	pass